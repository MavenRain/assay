mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def amount : Type 0 := Word 256
def deposit : Type 0 := prod (amount)
def set : Type 0 := prod (amount)
def ping : Type 0 := (prod () : Type 0)
def Entry : Type 0 := sum (deposit, set, ping)
def constructor : Eff := ret (word 256 0)
def fallback : Tx := abort
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : deposit) => store storage.0 args.0 (le args.0 (word 256 10) (done args.0) (abort))
  | 1 (args : set) => store storage.0 args.0 (done args.0)
  | 2 (args : ping) => done (word 256 17)
