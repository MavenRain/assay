mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | callvalue : (Word 256 -> Tx) -> Tx
  | payable : Tx -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def limit : Type 0 := Word 256
def observe : Type 0 := (prod () : Type 0)
def snapshot : Type 0 := prod (limit)
def bounded : Type 0 := prod (limit)
def sender : Type 0 := (prod () : Type 0)
def amount : Type 0 := (prod () : Type 0)
def fail : Type 0 := (prod () : Type 0)
def plain : Type 0 := (prod () : Type 0)
def Entry : Type 0 := sum (observe, snapshot, bounded, sender, amount, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => payable (done (word 256 17))
  | 1 (args : snapshot) => payable (done (word 256 17))
  | 2 (args : bounded) => payable (done (word 256 17))
  | 3 (args : sender) => payable (done (word 256 17))
  | 4 (args : amount) => payable (done (word 256 17))
  | 5 (args : fail) => payable (done (word 256 17))
  | 6 (args : plain) => done (word 256 17)
