mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | callvalue : (Word 256 -> Tx) -> Tx
  | calldatasize : (Word 256 -> Tx) -> Tx
  | payable : Tx -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def limit : Type 0 := Word 256
def observe : Type 0 := (prod () : Type 0)
def snapshot : Type 0 := prod (limit)
def bounded : Type 0 := prod (limit)
def sender : Type 0 := (prod () : Type 0)
def amount : Type 0 := (prod () : Type 0)
def fail : Type 0 := (prod () : Type 0)
def plain : Type 0 := (prod () : Type 0)
def Entry : Type 0 := sum (observe, snapshot, bounded, sender, amount, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => payable (calldatasize (fun (size : Word 256) => done size))
  | 1 (args : snapshot) => payable (calldatasize (fun (size : Word 256) => store storage.0 size (load storage.0 (fun (loaded : Word 256) => store storage.0 args.0 (calldatasize (fun (again : Word 256) => add loaded again (fun (result : ResultWord) => case result with | 0 (total : Word 256) => done total | 1 (unused : prod ()) => abort)))))))
  | 2 (args : bounded) => payable (calldatasize (fun (size : Word 256) => store storage.0 size (le size args.0 (done size) (abort))))
  | 3 (args : sender) => payable (calldatasize (fun (size : Word 256) => store storage.0 size (done size)))
  | 4 (args : amount) => payable (calldatasize (fun (size : Word 256) => store storage.0 size (callvalue (fun (value : Word 256) => done value))))
  | 5 (args : fail) => payable (calldatasize (fun (size : Word 256) => store storage.0 size (abort)))
  | 6 (args : plain) => calldatasize (fun (size : Word 256) => done size)
