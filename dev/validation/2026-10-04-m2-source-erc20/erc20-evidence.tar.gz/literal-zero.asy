contract Literal where storage State := { cell : Word }
entry get () : Eff Sig String := do sstore cell (word 9) ; pure (string 0x00)
constructor := do pure ()
