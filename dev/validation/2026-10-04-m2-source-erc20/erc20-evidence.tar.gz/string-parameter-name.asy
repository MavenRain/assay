contract StringParameter where storage State := { cell : Word }
entry get (string : String) : Eff Sig String := do pure (string)
constructor := do pure ()
