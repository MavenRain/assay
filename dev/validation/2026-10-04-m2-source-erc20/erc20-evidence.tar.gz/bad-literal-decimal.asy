contract BadLiteral where storage State := { cell : Word }
entry get () : Eff Sig String := do pure (string 12)
constructor := do pure ()
