contract BadLiteral where storage State := { cell : Word }
entry get () : Eff Sig String := do pure (string 0x01 0x02)
constructor := do pure ()
