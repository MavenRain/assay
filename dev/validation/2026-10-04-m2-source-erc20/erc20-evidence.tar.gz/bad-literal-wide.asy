contract BadLiteral where storage State := { cell : Word }
entry get () : Eff Sig String := do pure (string 0x0101010101010101010101010101010101010101010101010101010101010101)
constructor := do pure ()
