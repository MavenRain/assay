contract BadLiteral where storage State := { cell : Word }
entry get () : Eff Sig String := do pure (string 0xgg)
constructor := do pure ()
