contract BadLiteral where storage State := { cell : Word }
entry get () : Eff Sig String := do pure (string 0x1)
constructor := do pure ()
