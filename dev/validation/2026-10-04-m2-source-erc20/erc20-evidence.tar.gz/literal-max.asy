contract Literal where storage State := { cell : Word }
entry get () : Eff Sig String := do sstore cell (word 9) ; pure (string 0x000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e)
constructor := do pure ()
