mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | caller : (Word 256 -> Tx) -> Tx
  | callvalue : (Word 256 -> Tx) -> Tx
  | calldatasize : (Word 256 -> Tx) -> Tx
  | calldataload : Word 256 -> (Word 256 -> Tx) -> Tx
  | payable : Tx -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def offset : Type 0 := Word 256
def observe : Type 0 := prod (offset)
def snapshot : Type 0 := prod (offset)
def bounded : Type 0 := prod (offset)
def sender : Type 0 := prod (offset)
def amount : Type 0 := prod (offset)
def size : Type 0 := prod (offset)
def fail : Type 0 := prod (offset)
def plain : Type 0 := prod (offset)
def Entry : Type 0 := sum (observe, snapshot, bounded, sender, amount, size, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => payable (calldataload args.0 (fun (first : Word 256) => done first))
  | 1 (args : snapshot) => payable (calldataload args.0 (fun (first : Word 256) => calldataload (word 256 0) (fun (second : Word 256) => store storage.0 args.0 (done first))))
  | 2 (args : bounded) => payable (calldataload args.0 (fun (first : Word 256) => store storage.0 first (le first (word 256 42) (done first) (abort))))
  | 3 (args : sender) => payable (calldataload args.0 (fun (first : Word 256) => caller (fun (who : Word 256) => done who)))
  | 4 (args : amount) => payable (calldataload args.0 (fun (first : Word 256) => callvalue (fun (amount : Word 256) => done amount)))
  | 5 (args : size) => payable (calldataload args.0 (fun (first : Word 256) => calldatasize (fun (size : Word 256) => done size)))
  | 6 (args : fail) => payable (calldataload args.0 (fun (first : Word 256) => store storage.0 first (abort)))
  | 7 (args : plain) => calldataload args.0 (fun (first : Word 256) => done first)
