mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def Denied : Type 0 := (prod () : Type 0)
def Error : Type 0 := sum (Denied)
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | reject : Error -> Tx
  | caller : (Word 256 -> Tx) -> Tx
  | callvalue : (Word 256 -> Tx) -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def amount : Type 0 := Word 256
def observe : Type 0 := (prod () : Type 0)
def snapshot : Type 0 := prod (amount)
def bounded : Type 0 := prod (amount)
def sender : Type 0 := (prod () : Type 0)
def fail : Type 0 := (prod () : Type 0)
def plain : Type 0 := (prod () : Type 0)
def Entry : Type 0 := sum (observe, snapshot, bounded, sender, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => callvalue (fun (value : Word 256) => done value)
  | 1 (args : snapshot) => callvalue (fun (value : Word 256) => store storage.0 value (load storage.0 (fun (loaded : Word 256) => store storage.0 args.0 (callvalue (fun (again : Word 256) => add loaded again (fun (result : ResultWord) => case result with | 0 (total : Word 256) => done total | 1 (unused : prod ()) => abort))))))
  | 2 (args : bounded) => callvalue (fun (value : Word 256) => store storage.0 value (le value args.0 (done value) (reject (inj 0 of 1 (tuple ()) : Error))))
  | 3 (args : sender) => callvalue (fun (value : Word 256) => store storage.0 value (caller (fun (sender : Word 256) => done sender)))
  | 4 (args : fail) => callvalue (fun (value : Word 256) => store storage.0 value (reject (inj 0 of 1 (tuple ()) : Error)))
  | 5 (args : plain) => callvalue (fun (value : Word 256) => done value)
