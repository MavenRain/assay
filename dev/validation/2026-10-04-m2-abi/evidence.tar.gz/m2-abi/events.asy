contract AbiMutability where
  storage State := { counter : Uint8 ; balances : Mapping Address Uint256 ;
    allowances : Mapping Address (Mapping Address Uint256) }
  event Seen (owner : Address indexed) (value : Uint256)
  entry lookup (owner : Address) : Eff Sig Uint256 := do
    value <- sload balances owner ; pure value
  entry nested (owner : Address) (spender : Address) : Eff Sig Uint256 := do
    value <- sload allowances owner spender ; pure value
  entry guarded (owner : Address) : Eff Sig Uint256 := do
    value <- sload balances owner ; guard le (word 0) value ;
    result <- add value (word 1) ; pure result
  entry scalarAfter (owner : Address) : Eff Sig Uint256 := do
    value <- sload balances owner ; sstore counter (word 1) ; pure value
  entry scalarBefore (owner : Address) : Eff Sig Uint256 := do
    sstore counter (word 1) ; value <- sload balances owner ; pure value
  entry mappingWrite (owner : Address) : Eff Sig Uint256 := do
    value <- sload balances owner ; sstore balances owner (word 1) ; pure value
  entry nestedWrite (owner : Address) (spender : Address) : Eff Sig Uint256 := do
    sstore allowances owner spender (word 1) ; pure (word 1)
  payable entry payableRead (owner : Address) : Eff Sig Uint256 := do
    value <- sload balances owner ; pure value
  payable entry payableWrite (owner : Address) : Eff Sig Uint256 := do
    sstore balances owner (word 1) ; pure (word 1)
  entry eventRead (owner : Address) : Eff Sig Uint256 := do
    value <- sload balances owner ; emit Seen (owner) (value) ; pure value
  constructor := do sstore counter (word 0) ; pure ()
