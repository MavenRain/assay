mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | caller : (Word 256 -> Tx) -> Tx
  | callvalue : (Word 256 -> Tx) -> Tx
  | calldatasize : (Word 256 -> Tx) -> Tx
  | address : (Word 256 -> Tx) -> Tx
  | payable : Tx -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def argument : Type 0 := Word 256
def observe : Type 0 := prod (argument)
def snapshot : Type 0 := prod (argument)
def remember : Type 0 := prod (argument)
def bounded : Type 0 := prod (argument)
def sender : Type 0 := prod (argument)
def amount : Type 0 := prod (argument)
def size : Type 0 := prod (argument)
def dataword : Type 0 := prod (argument)
def fail : Type 0 := prod (argument)
def plain : Type 0 := prod (argument)
def Entry : Type 0 := sum (observe, snapshot, remember, bounded, sender, amount, size, dataword, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => payable (address (fun (self : Word 256) => done self))
  | 1 (args : snapshot) => payable (address (fun (self : Word 256) => load storage.0 (fun (later : Word 256) => address (fun (later : Word 256) => calldatasize (fun (later : Word 256) => callvalue (fun (later : Word 256) => caller (fun (later : Word 256) => store storage.0 args.0 (done self))))))))
  | 2 (args : remember) => payable (address (fun (self : Word 256) => store storage.0 self (done self)))
  | 3 (args : bounded) => payable (address (fun (self : Word 256) => store storage.0 self (le self args.0 (done self) (abort))))
  | 4 (args : sender) => payable (address (fun (self : Word 256) => caller (fun (v : Word 256) => done v)))
  | 5 (args : amount) => payable (address (fun (self : Word 256) => callvalue (fun (v : Word 256) => done v)))
  | 6 (args : size) => payable (address (fun (self : Word 256) => calldatasize (fun (v : Word 256) => done v)))
  | 7 (args : dataword) => payable (address (fun (self : Word 256) => done self))
  | 8 (args : fail) => payable (address (fun (self : Word 256) => store storage.0 self (abort)))
  | 9 (args : plain) => address (fun (self : Word 256) => done self)
