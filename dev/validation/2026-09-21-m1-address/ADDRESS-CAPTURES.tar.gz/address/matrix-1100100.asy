mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def wordNat : Word 256 -> Nat := fun (w : Word 256) =>
  case w as x in Word bits return Nat with | word 0 bits n => n
def Le : Word 256 -> Word 256 -> Prop := fun (a : Word 256) (b : Word 256) =>
  case natLt (wordNat b) (wordNat a) as flag return Prop with
  | 0 (_u : prod ()) => prod () | 1 (_u : prod ()) => sum ()
def AddFits : Word 256 -> Word 256 -> Prop := fun (a : Word 256) (b : Word 256) =>
  case natLt (natAdd (wordNat a) (wordNat b)) 115792089237316195423570985008687907853269984665640564039457584007913129639936 as flag return Prop with
  | 0 (_u : prod ()) => sum () | 1 (_u : prod ()) => prod ()
def Denied : Type 0 := (prod () : Type 0)
def Error : Type 0 := sum (Denied)
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | reject : Error -> Tx
  | guardLe : (a : Word 256) -> (b : Word 256) -> ((0 p : Le a b) -> Tx) -> Tx -> Tx
  | guardAdd : (a : Word 256) -> (b : Word 256) -> ((0 p : AddFits a b) -> Tx) -> Tx -> Tx
  | addLt : (a : Word 256) -> (b : Word 256) -> (0 p : AddFits a b) -> (Word 256 -> Tx) -> Tx
  | subLe : (a : Word 256) -> (b : Word 256) -> (0 p : Le b a) -> (Word 256 -> Tx) -> Tx
  | calldatasize : (Word 256 -> Tx) -> Tx
  | address : (Word 256 -> Tx) -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def argument : Type 0 := Word 256
def observe : Type 0 := prod (argument)
def snapshot : Type 0 := prod (argument)
def remember : Type 0 := prod (argument)
def bounded : Type 0 := prod (argument)
def sender : Type 0 := prod (argument)
def amount : Type 0 := prod (argument)
def size : Type 0 := prod (argument)
def dataword : Type 0 := prod (argument)
def fail : Type 0 := prod (argument)
def plain : Type 0 := prod (argument)
def Entry : Type 0 := sum (observe, snapshot, remember, bounded, sender, amount, size, dataword, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => address (fun (self : Word 256) => done self)
  | 1 (args : snapshot) => address (fun (self : Word 256) => load storage.0 (fun (later : Word 256) => address (fun (later : Word 256) => calldatasize (fun (later : Word 256) => store storage.0 args.0 (done self)))))
  | 2 (args : remember) => address (fun (self : Word 256) => store storage.0 self (done self))
  | 3 (args : bounded) => address (fun (self : Word 256) => store storage.0 self (guardLe self args.0 (fun (0 p : Le self args.0) => done self) (reject (inj 0 of 1 (tuple ()) : Error))))
  | 4 (args : sender) => address (fun (self : Word 256) => done self)
  | 5 (args : amount) => address (fun (self : Word 256) => done self)
  | 6 (args : size) => address (fun (self : Word 256) => calldatasize (fun (v : Word 256) => done v))
  | 7 (args : dataword) => address (fun (self : Word 256) => done self)
  | 8 (args : fail) => address (fun (self : Word 256) => store storage.0 self (reject (inj 0 of 1 (tuple ()) : Error)))
  | 9 (args : plain) => address (fun (self : Word 256) => done self)
