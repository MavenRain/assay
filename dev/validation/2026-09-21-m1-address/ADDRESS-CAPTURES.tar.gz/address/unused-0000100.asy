mu Word : (0 bits : Nat) -> Type 0 :=
  | word : (0 bits : Nat) -> Nat -> Word bits
mu Eff : Type 0 :=
  | ret : Word 256 -> Eff
  | put : Word 256 -> Word 256 -> Eff -> Eff
  | read : Word 256 -> Eff
axiom EvmOpcodes : Prop
def ResultWord : Type 0 := sum (Word 256, prod ())
mu Tx : Type 0 :=
  | done : Word 256 -> Tx
  | store : Word 256 -> Word 256 -> Tx -> Tx
  | load : Word 256 -> (Word 256 -> Tx) -> Tx
  | add : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | sub : Word 256 -> Word 256 -> (ResultWord -> Tx) -> Tx
  | le : Word 256 -> Word 256 -> Tx -> Tx -> Tx
  | abort : Tx
  | calldatasize : (Word 256 -> Tx) -> Tx

def cell : Type 0 := Word 256
def Storage : Type 0 := prod (cell)
def storage : Storage := tuple (word 256 0)
def argument : Type 0 := Word 256
def observe : Type 0 := prod (argument)
def snapshot : Type 0 := prod (argument)
def remember : Type 0 := prod (argument)
def bounded : Type 0 := prod (argument)
def sender : Type 0 := prod (argument)
def amount : Type 0 := prod (argument)
def size : Type 0 := prod (argument)
def dataword : Type 0 := prod (argument)
def fail : Type 0 := prod (argument)
def plain : Type 0 := prod (argument)
def Entry : Type 0 := sum (observe, snapshot, remember, bounded, sender, amount, size, dataword, fail, plain)
def constructor : Eff := ret (word 256 0)
def main : Entry -> Tx := fun (entry : Entry) => case entry with
  | 0 (args : observe) => done (word 256 17)
  | 1 (args : snapshot) => done (word 256 17)
  | 2 (args : remember) => done (word 256 17)
  | 3 (args : bounded) => done (word 256 17)
  | 4 (args : sender) => done (word 256 17)
  | 5 (args : amount) => done (word 256 17)
  | 6 (args : size) => done (word 256 17)
  | 7 (args : dataword) => done (word 256 17)
  | 8 (args : fail) => done (word 256 17)
  | 9 (args : plain) => done (word 256 17)
